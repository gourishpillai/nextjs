# Next.js 13 Full Course 2023 | Build and Deploy a Full Stack App Using the Official React Framework
![AI Prompt Sharing](https://i.ibb.co/9pQNZZy/Thumbnail-27.png)

### [🌟 Become a top 1% Next.js 13 developer in only one course](https://jsmastery.pro/next13)
### [🚀 Land your dream programming job in 6 months](https://jsmastery.pro/masterclass)

## Introduction
Next.js recently became the official React framework as outlined in React docs. In this course, you'll learn the most important Next.js concepts and how they fit into the React ecosystem. Finally, you'll put your skills to the test by building a modern full-stack Next 13 application.
 
In this video, you'll learn:
- Next.js 13 App Folder Structure
- Next.js 13 Client Components vs Server Components
- Next.js 13 File-based Routing (including dynamic and nested routes)
- Next.js 13 page, layout, loading, and error Special Files
- Next.js 13 Serverless Route Handlers (Next API, Full Stack Apps)
- Next.js 13 Metadata and Search Engine Optimization (SEO)
- Three ways to fetch data in Next.js:
   - Server Side Rendering (SSR),
   - Static Site Generation (SSG)
   - Incremental Static Generation (ISR)

## Want to land your dream programming job in 3 - 6 months?
⭐ JSM Masterclass Experience - https://jsmastery.pro/masterclass
Become a Software Engineer. Guaranteed.
